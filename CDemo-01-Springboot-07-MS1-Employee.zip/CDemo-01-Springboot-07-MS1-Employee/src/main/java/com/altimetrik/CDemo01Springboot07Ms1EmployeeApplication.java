package com.altimetrik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CDemo01Springboot07Ms1EmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CDemo01Springboot07Ms1EmployeeApplication.class, args);
	}

}
