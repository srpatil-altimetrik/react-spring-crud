package com.altimetrik;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CDemo01Springboot07Ms1EmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
