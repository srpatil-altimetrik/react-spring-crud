import './App.css';
import DELETE from './Components/DELETE';
import DISPALY from './Components/DISPALY';
import DISPALYBYID from './Components/DISPALYBYID';
import INSERT from './Components/INSERT';
import UDPDATE from './Components/UPDATE';
import DELETEBYID from './Components/DELETEBYID';
import { Link, Navigate } from 'react-router-dom';
import React from 'react';

import {
  BrowserRouter as Router,
  Route,
  Routes,
} from 'react-router-dom';

function App() {
  return (
    <Router>
      <div style={{ textAlign: 'center' }}>
        <h1>Hi Welcome to React JS Application</h1>
        <h2>
          <Link to="/insert">INSERT</Link> ||{' '}
          <Link to="/display">DISPLAY</Link> ||{' '}
          <Link to="/displaybyid">DISPLAYBYID</Link> ||{' '}
          <Link to="/update">UDPDATE</Link> ||{' '}
          <Link to="/delete">DELETE</Link> ||{' '}
          <Link to="/deletebyid">DELETEBYID</Link>
        </h2>

        <Routes>
          <Route path="/" element={<Navigate to="/display" />} />
          <Route path="/insert" element={<INSERT />} />
          <Route path="/display" element={<DISPALY />} />
          <Route path="/displaybyid" element={<DISPALYBYID />} />
          <Route path="/update" element={<UDPDATE />} />
          <Route path="/delete" element={<DELETE />} />
          <Route path="/deletebyid" element={<DELETEBYID />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
