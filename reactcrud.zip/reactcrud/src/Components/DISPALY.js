import React, { useEffect, useState, startTransition } from 'react';
import axios from 'axios';

const DISPALY = () => {

    const [data, setData] = useState([]);

    useEffect(() => {
        startTransition(() => {
            fetchData();
        });
    }, []);

    const fetchData = () => {
        axios.get('http://localhost:8081/ms1/getAllEmployees')
            .then(response => {
              // if(response.status===200)
              // {
              //   console.log(response)
              //   setData(response.data);
              // }
              // else{
              //   console.log("Somthing went wrong ")
              // }
                console.log(response)
                setData(response.data);
            })
            .catch(error => {
                console.log(error);
            });
    }

    return (
        <div className='card'>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
            <table>
                <thead>
                    <tr>
                        <th>UserID </th>
                        <th>Name </th>
                        <th>Salary </th>
                        <th>Designation </th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((item) => (
                        <tr key={item.empId}>
                            <td>{item.empId}</td>
                            <td>{item.empName}</td>
                            <td>{ item.empSalary} </td>
                            <td>{item.empDesignation}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default DISPALY;