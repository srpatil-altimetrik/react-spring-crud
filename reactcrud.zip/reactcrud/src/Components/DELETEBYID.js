import React, { useState } from 'react';
import axios from 'axios';

const DELETEBYID = () => {
  const [empId, setEmpId] = useState('');
  const [message, setMessage] = useState('');

  const handleDelete = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.delete(`http://localhost:8081/ms1/deleteEmployeeById/${empId}`);
      console.log(response);
      setMessage(`Employee with ID ${empId} deleted successfully.`);
      setEmpId(''); // Clear the input
    } catch (error) {
      console.error('Error deleting employee:', error.message);
      setMessage('Failed to delete employee. Please check the ID.');
    }
  };

  return (
    <div className='card' style={{ textAlign: 'center' }}>
      <h1>Delete Employee</h1>
      <form onSubmit={handleDelete}>
        <input
          name="empId"
          type="text"
          value={empId}
          onChange={(e) => setEmpId(e.target.value)}
          placeholder="Enter Employee ID"
          required
        />
        <div style={{ paddingTop: "8px" }}>
          <button type="submit">Delete Employee</button>
        </div>
      </form>
      {message && <p style={{ color: 'green', marginTop: '10px' }}>{message}</p>}
    </div>
  );
};

export default DELETEBYID;
