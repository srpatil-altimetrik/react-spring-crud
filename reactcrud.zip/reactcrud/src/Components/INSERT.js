import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // 👈 for navigation

const INSERT = () => {
  const [formData, setFormData] = useState({});
  const navigate = useNavigate(); // 👈 for navigation

  const handleInsert = async (e) => {
    e.preventDefault();

    let data = {
      empId: e.target[0].value,
      empName: e.target[1].value,
      empSalary: e.target[2].value,
      empDesignation: e.target[3].value
    };

    setFormData(data);

    try {
      const response = await axios.post('http://localhost:8081/ms1/addEmployee', data);
      console.log(response);
      alert("Employee added successfully!");
      navigate('/display'); 
    } catch (error) {
      console.error('Error adding employee:', error.message);
      alert("Failed to add employee.");
    }
  };

  return (
    <div className='card' style={{ textAlign: 'center' }}>
      <h1>ADD Employee</h1>
      <form onSubmit={handleInsert}>
        <input
          name="empId"
          type="text"
          placeholder="Enter Employee ID"
        />
        <div style={{ marginTop: "4px" }}></div>
        <input
          name="empName"
          type="text"
          placeholder="Enter Name"
        />
        <div style={{ marginTop: "4px" }}></div>
        <input
          name="empSalary"
          type="number"
          placeholder="Enter Salary"
        />
        <div style={{ marginTop: "4px" }}></div>
        <input
          name="empDesignation"
          type="text"
          placeholder="Enter Designation"
        />
        <div style={{ paddingTop: "8px" }}>
          <button
            type="submit"
            className="mt-4 h-12 w-full"
          >
            ADD Employee
          </button>
        </div>
      </form>
    </div>
  );
};

export default INSERT;
