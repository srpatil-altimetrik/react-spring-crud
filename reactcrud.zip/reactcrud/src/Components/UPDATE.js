import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const UPDATE = () => {
  const [formData, setFormData] = useState({});
  const navigate = useNavigate();

  const handleUpdate = async (e) => {
    e.preventDefault();

    const empId = e.target[0].value;
    const data = {
      empName: e.target[1].value,
      empSalary: e.target[2].value,
      empDesignation: e.target[3].value
    };

    setFormData({ empId, ...data });

    try {
      const response = await axios.put(`http://localhost:8081/ms1/updateEmployeeById/${empId}`, data);
      console.log(response);
      alert("Employee updated successfully!");
      navigate('/display');
    } catch (error) {
      console.error('Error updating employee:', error.message);
      alert("Failed to update employee.");
    }
  };

  return (
    <div className='card' style={{ textAlign: 'center' }}>
      <h1>UPDATE Employee</h1>
      <form onSubmit={handleUpdate}>
        <input name="empId" type="text" placeholder="Enter Employee ID" />
        <div style={{ marginTop: "4px" }}></div>
        <input name="empName" type="text" placeholder="Enter Name" />
        <div style={{ marginTop: "4px" }}></div>
        <input name="empSalary" type="number" placeholder="Enter Salary" />
        <div style={{ marginTop: "4px" }}></div>
        <input name="empDesignation" type="text" placeholder="Enter Designation" />
        <div style={{ paddingTop: "8px" }}>
          <button type="submit" className="mt-4 h-12 w-full">
            UPDATE Employee
          </button>
        </div>
      </form>
    </div>
  );
};

export default UPDATE;
