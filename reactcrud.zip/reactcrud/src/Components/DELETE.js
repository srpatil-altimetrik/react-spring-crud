import React from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const DELETEALL = () => {
  const navigate = useNavigate();

  const handleDeleteAll = async () => {
    const confirmDelete = window.confirm("Are you sure you want to delete ALL employees? This action cannot be undone!");
    if (!confirmDelete) return;

    try {
      await axios.delete('http://localhost:8081/ms1/deleteAllEmployees');
      alert("All employees deleted successfully!");
      navigate('/display');
    } catch (error) {
      console.error('Error deleting all employees:', error.message);
      alert("Failed to delete all employees.");
    }
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Delete All Employees</h1>
      <button 
        onClick={handleDeleteAll} 
        style={{ padding: '10px 20px', fontSize: '18px', cursor: 'pointer' }}
      >
        DELETE ALL
      </button>
    </div>
  );
};

export default DELETEALL;
