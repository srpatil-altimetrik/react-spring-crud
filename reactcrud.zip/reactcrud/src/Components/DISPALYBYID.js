import React, { useState } from 'react';
import axios from 'axios';

const DISPLAYBYID = () => {
    const [empId, setEmpId] = useState('');
    const [employee, setEmployee] = useState(null);
    const [error, setError] = useState('');

    const fetchEmployeeById = () => {
        axios.get(`http://localhost:8081/ms1/getEmployeeById/${empId}`)
            .then(response => {
                console.log(response);
                setEmployee(response.data);
                setError('');
            })
            .catch(error => {
                console.error(error);
                setEmployee(null);
                setError("Employee not found or error fetching data.");
            });
    };

    return (
        <div className='card'>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />

            <div>
                <label>Enter Employee ID: </label>
                <input
                    type="text"
                    value={empId}
                    onChange={(e) => setEmpId(e.target.value)}
                />
                <button onClick={fetchEmployeeById}>Search</button>
            </div>

            {error && <p style={{ color: 'red' }}>{error}</p>}

            {employee && (
                <table>
                    <thead>
                        <tr>
                            <th>UserID</th>
                            <th>Name</th>
                            <th>Salary</th>
                            <th>Designation</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>{employee.empId}</td>
                            <td>{employee.empName}</td>
                            <td>{employee.empSalary}</td>
                            <td>{employee.empDesignation}</td>
                        </tr>
                    </tbody>
                </table>
            )}
        </div>
    );
};

export default DISPLAYBYID;
